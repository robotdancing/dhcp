/* @(#) $Id: version.h 239 2009-03-14 05:44:54Z leres $ (LBL) */

extern const char version[];
